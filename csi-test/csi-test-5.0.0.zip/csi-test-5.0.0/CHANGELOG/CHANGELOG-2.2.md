# Changelog since v2.1.0

## New Features

- Adds an interface for generating Volume/Node IDs that users can plug in for ID's that must conform to valid format ([#212](https://github.com/kubernetes-csi/csi-test/pull/212), [@davidz627](https://github.com/davidz627))


